Windows Install Instructions:
Install Twisted 
Install ActivePython 2.7
pypm install avro
pypm install zope.interface
Download pyOpenSSL (https://launchpad.net/pyopenssl/+download)
easy_install pyOpenSSL-0.11-py2.7-win32.egg
copy smap-data-read-only\schema to C:\Python27\Lib\site-packages\smap
