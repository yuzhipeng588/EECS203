ROOT = 'http://www.buildingmanageronline.com/members/'
STATUSPAGE = 'client_status.php?DB=dbU216ucberkelF682'
AUTH = ('ucbguest', 'ucbguest')
BMOAUTH = AUTH
