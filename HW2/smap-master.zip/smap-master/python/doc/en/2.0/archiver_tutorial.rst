sMAP archiver tutorial
======================

Data model goes here.

Task 4: Configuring ``smap-query``
----------------------------------

Task 5: Selecting several time series
-------------------------------------

Task 6: Downloading time series data in Python
----------------------------------------------
