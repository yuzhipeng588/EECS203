#!/bin/bash
/home/sagar/Desktop/smap-status.py -s 'ISO Data' -d miso.MIsoDriver -t 5
